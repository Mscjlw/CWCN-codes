# read in the R libraries
library(MASS)	# standard, no need to install
library(class)	# standard, no need to install
library(cluster)	# standard, no need to install
library(sma)	# install it for the function plot.mat 
library(impute)	# install it for imputing missing value
library(Hmisc)	# install it for the C-index calculations
# read in the custom network functions
source("D:/JAEL Paper Aids/Thesis/Datasets/NetworkFunctions.txt")
library(WGCNA)
options(stringsAsFactors = F)


#####ANALYSIS OF YPPI & YGE DATASETS##############################
setwd("D:/JAEL Paper Aids/2nd Paper/Manuscript submission/codes")
source("D:/JAEL Paper Aids/2nd Paper/Data/Datasets/YPPINetworkFunctions.txt");
source("D:/JAEL Paper Aids/2nd Paper/Data/Datasets/YPPINetworkFunctions1.txt");
NodeNames=read.csv(file = "D:/JAEL Paper Aids/2nd Paper/Data/Datasets/YeastPPI_nodes.csv", header=F)
NodeNames=as.vector(NodeNames[,1])
ADJ1=read.csv("D:/JAEL Paper Aids/2nd Paper/Data/Datasets/YeasyPPI_ADJ.csv", header=F)
ADJ1=as.matrix(ADJ1)
dim(ADJ1)
rownames(ADJ1)=NodeNames; 
colnames(ADJ1)=NodeNames;
datExprADJ1 <- as.data.frame(t(ADJ1))
names(datExprADJ1)
# We use the TOM matrix as a smoothed-out version of the adjacency matrix.
dissGTOM1=TOMdist1(as.matrix(ADJ1))
ADJ=1- dissGTOM1
Degree <- apply(ADJ,2,sum)
DegCut = 2000 # number of most connected genes that will be considered 
DegreeRank <- rank(-Degree)	
restDegreeADJ <- DegreeRank <= DegCut
sum(restDegreeADJ)
AdjMat1rest <- ADJ[restDegreeADJ,restDegreeADJ]
dissGTOM1=TOMdist1(as.matrix(AdjMat1rest))
collect_garbage()

# Now we carry out hierarchical clustering with the TOM matrix. Branches of the 
# resulting clustering tree will be used to define gene modules.

hierGTOM1 <- hclust(as.dist(dissGTOM1),method="average");
windows(width=8, height=5)
par(mfrow=c(1,1), mar=c(0,2,2,0))
plot(hierGTOM1,labels=F, cex=0.2)
myheightcutoff    =0.93
mydeepSplit       =  T # fine structure within module
myminModuleSize   = 50 # modules must have this minimum number of genes
myminAttachModuleSize=5
#new way  for identifying modules based on hierarchical clustering dendrogram
colorh1=cutreeDynamic(hierclust= hierGTOM1, deepSplit=mydeepSplit, maxTreeHeight=myheightcutoff, minModuleSize=myminModuleSize, minAttachModuleSize=myminAttachModuleSize, nameallmodules=T, useblackwhite=F)

table(colorh1)
colorlevel1=levels(factor(colorh1))
#Hierarchical clustering dendrogram and module definition
windows()
par(mfrow=c(2,1), mar=c(2,2,2,1))
plot(hierGTOM1, main="Yeast Protein-protein Interaction Network", labels=F, xlab="", sub="");
hclustplot1(hierGTOM1,colorh1, title1="Colored by module membership")

collect_garbage()

###############Detection of hub genes
ConnectivityMeasuresdataOne=intramodularConnectivity(AdjMat1rest,colors=colorh1) 
names(ConnectivityMeasuresdataOne) 
colorlevels=levels(factor(colorh1)) 
par(mfrow=c(2,3)) 
for (i in c(1:length(colorlevels) ) ) { 
  whichmodule=colorlevels[[i]];restrict1=colorh1==whichmodule 
  verboseScatterplot(ConnectivityMeasuresdataOne$kWithin[restDegreeADJ], AdjMat1rest,col=colorh1,main= paste("set I,", whichmodule),ylab="Gene Significance",xlab="Intramodular k") 
} 

# The following verifies that module definition is relatively robust to the height cutoff.
# This is especially true for tighter modules (more distinctive branches).
windows(width=8, height=10)
par(mfrow=c(6,1), mar=c(2,2,2,1))
plot(hierGTOM1, main="Standard TOM Measure", labels=F, xlab="", sub="");
hclustplot1(hierGTOM1,colorh1, title1="Our chosen height cutoff = 0.93")
for(varheightcutoff in c(0.92, 0.94, 0.95, 0.96) ){
  colorhvar=cutreeDynamic(hierclust= hierGTOM1, deepSplit=mydeepSplit, maxTreeHeight=varheightcutoff, minModuleSize=myminModuleSize, minAttachModuleSize=myminAttachModuleSize, nameallmodules=T, useblackwhite=F)
  hclustplot1(hierGTOM1,colorhvar, title1=paste("Height cutoff =", varheightcutoff)) 
}


#  Calculate the fundamental network concepts
colorlevel1=levels(factor(colorh1))
grey=45 # To flag which module is the grey module
ADJ=as.matrix(ADJ)

# Then, we apply FDADJ() to the unweighted network.
time.start=Sys.time()
for(i in c(1:length(colorlevel1)) ){
  adjtemp= ADJ[colorh1==colorlevel1[i], colorh1==colorlevel1[i]]
  assign(paste("FDsoft", colorlevel1[i],sep=""), FDADJ(adjtemp))
  rm(adjtemp);collect_garbage()
}
time.end=Sys.time()
time.end-time.start # total time for running this part

# Construct the table 1.
module.soft=matrix(NA, ncol=length(colorlevel1), nrow= length(FDsoftturquoise$summary.names))
colnames(module.soft)=colorlevel1
rownames(module.soft)= FDsoftturquoise$summary.names
for(i in 1:length(colorlevel1)){
  temp=eval(as.name(paste("FDsoft",colorlevel1[i],sep="")))
  module.soft[,i]=temp$summary
}
signif(module.soft[-1,],3)
write.table(module.soft, "FlyProtein11.xls", sep="\t", row.names=T, col.names=T)
###Heatmap of the TOM Matrix for the turquoise Module. 
i=1 ### i=1 for turquoise module and i=3 for brown module.
adjtemp=ADJ[colorh1==colorlevel1[i], colorh1==colorlevel1[i]]
dissGTOM2=TOMdist1(as.matrix(adjtemp))
hierGTOM2 = hclust(as.dist(dissGTOM2),method="average");
windows()
TOMplot1(dissGTOM2 , hierGTOM2, rep(colorlevel1[i], module.soft[1,i]) )
rm(adjtemp, dissGTOM2);collect_garbage()


##########Heatmap for all modules
# for visualizing the network. Here we chose 2 scaling dimensions
windows()
cmd1=cmdscale(as.dist(dissGTOM1),2)
par(mfrow=c(1,1))
plot(cmd1, col=as.character(colorh1),  main="MDS plot", xlab="Scaling Dimension 1", ylab="Scaling Dimension 2")

windows()
TOMplot1(dissGTOM1 , hierGTOM1, colorh1)


#Dynamic Tree Cut may identify modules whose expression profiles are very similar. It may be prudent to merge such modules since their genes are highly co-expressed
# Calculate eigengenes 
MEList = moduleEigengenes(datExprADJ1[restDegreeADJ], colors = colorh1) 
MEs = MEList$eigengenes 
# Calculate dissimilarity of module eigengenes 
MEDiss = 1-cor(MEs); 
# Cluster module eigengenes 
METree = hclust(as.dist(MEDiss), method = "average"); 
# Plot the result 
windows() 
plot(METree, main = "Clustering of module eigengenes", xlab = "", sub = "")
#We choose a height cut of 0.25, corresponding to correlation of 0.75, to merge 
MEDissThres = 0.25 
# Call an automatic merging function 
merge = mergeCloseModules(datExprADJ1[restDegreeADJ], colorh1, cutHeight = MEDissThres, verbose = 3) 
# The merged module colors 
mergedColors = merge$colors;
# Eigengenes of the new merged modules: 
mergedMEs = merge$newMEs;
#To see what the merging did to our module colors, we plot the gene dendrogram again, with the original and merged module colors underneath
windows()
#pdf(file = "Plots/geneDendro-3.pdf", wi = 9, he = 6) 
plotDendroAndColors(hierGTOM1, cbind(colorh1, mergedColors), c("Dynamic Tree Cut", "Merged dynamic"), dendroLabels = FALSE, hang = 0.03, addGuide = TRUE, guideHang = 0.05) 
# Rename to moduleColors 
moduleColors = mergedColors 
# Construct numerical labels corresponding to the colors 
colorOrder = c("grey", standardColors(50)); 
moduleLabels = match(moduleColors, colorOrder)-1; 
moduleColors = labels2colors(colorh1)
MEs = mergedMEs; 
geneTree = merge$dendrograms[[1]];
#Relating modules to external clinical traits
# Define numbers of genes and samples



###YGE dataset analysis
library(WGCNA)
setwd("D:/JAEL Paper Aids/2nd Paper/Data");
source("D:/JAEL Paper Aids/2nd Paper/Data/Datasets/YGENetworkFunctions.txt"); 
source("D:/JAEL Paper Aids/2nd Paper/Data/Datasets/YGENetworkFunctions1.txt");
# Prepare the data
dat0 <- read.csv(file ="D:/JAEL Paper Aids/2nd Paper/Data/Datasets/YEASTCellCycle4000.csv",header=T, row.names=1)
dim(dat0)
# the following gene summary file contains information on the yeast genes
datSummary=dat0[,1:10]
# the column essentiality indicates which gene is essential for yeast survival
table(datSummary$essentiality)
# message: there are 645 essential genes
# the following data frame contains the gene expression data: columns are genes, rows are arrays (samples) 
datExpr = t(dat0[,8:51])
names(datExpr)
datExprYeast=as.data.frame(t(dat0[,-c(1:7)]))
names(datExprYeast)
# This following code allow us to restrict our analysis
# to the most varying genes
var1=function(x) var(x,na.rm=T)
vargenes=apply(datExpr,2,var1)
rankvar=rank(-vargenes)
restVariance= rankvar< 4001 #i.e. we keep all genes.
sum(restVariance)
datExpr=datExpr[,restVariance]
datSummary=datSummary[restVariance,]
no.samples = dim(datExpr)[[1]]
dim(datExpr)
rm(Yeastdata);gc()
# Plot the sample tree: Open a graphic output window

# The user should change the dimensions if the window is too large or too small.
require(graphics)
require(flashClust)
sampleTree = flashClust(dist(datExpr), method = "average");
windows()
par(cex = 0.6);
par(mar = c(0,4,2,0))
plot(sampleTree, main = "Sample clustering to detect outliers", sub="", xlab="", cex.lab = 1.5, cex.axis = 1.5, cex.main = 2)
# Now we produce the scale free topology fitting indices for different
# soft thresholds (powers). It will be used to pick a soft threshold.
powers1=c(seq(1,10,by=1), seq(12,20, by=2))
RpowerTable=PickSoftThreshold(datExpr,powervector=powers1)[[2]]
collect_garbage()
windows()
cex1=1
par(mfrow=c(1,2))
plot(RpowerTable[,1], -sign(RpowerTable[,3])*RpowerTable[,2],xlab="Soft Threshold (power)",ylab="Scale Free Topology Model Fit,signed R^2",type="n")
text(RpowerTable[,1], -sign(RpowerTable[,3])*RpowerTable[,2],labels=powers1,cex=cex1,col="red")
# this line corresponds to using an R^2 cut-off of h
abline(h=0.85,col="red")
plot(RpowerTable[,1], RpowerTable[,5],xlab="Soft Threshold (power)",ylab="Mean Connectivity", type="n")
text(RpowerTable[,1], RpowerTable[,5], labels=powers1, cex=cex1,col="red")


beta1=7
Connectivity=softConnectivity(datExpr,power=beta1)
ConnectivityCut = 2000 # number of most connected genes that will be considered
ConnectivityRank = rank(-Connectivity)
restConnectivity = ConnectivityRank <= ConnectivityCut
# thus our module detection uses the following number of genes
sum(restConnectivity)

ADJrest = adjacency(datExpr[,restConnectivity], power=beta1)
# The following code computes the topological overlap matrix based on the
# adjacency matrix.
dissTOM=TOMdist(ADJrest)
gc()
# Now we carry out hierarchical clustering with the TOM matrix. Branches of the
# resulting clustering tree will be used to define gene modules.
hierTOM = hclust(as.dist(dissTOM),method="average");
par(mfrow=c(1,1))
windows()
plot(hierTOM,labels=F,sub="",xlab="")
# GREY IS RESERVED to color genes that are not part of any module.
# We only consider modules that contain at least 125 genes.
colorh1= cutreeStaticColor(hierTOM,cutHeight = 0.97)
table(colorh1)
colorlevel1=levels(factor(colorh1))
summary(colorh1)
GeneSignificance=datSummary$essentiality[restConnectivity]

windows()
par(mfrow=c(2,1), mar=c(0,2,2,0))
plot(hierTOM, main="Yeast Co-expression Network: Soft Thresholding", labels=F, xlab="", sub="");
hclustplot1(hierTOM,colorh1, title1="Colored by module membership")
# The following verifies that module definition is relatively robust to the height cutoff.
# This is especially true for tighter modules (more distinctive branches).
windows(width=8, height=10)
par(mfrow=c(6,1), mar=c(2,2,2,1))
plot(hierTOM, main="Standard TOM Measure", labels=F, xlab="", sub="");
hclustplot1(hierTOM,colorh1, title1="Our chosen height cutoff = 0.94")
for(varheightcutoff in c(0.94, 0.95, 0.96, 0.975) ){
  colorhvar=as.character(modulecolor2(hierTOM,h1=varheightcutoff))
  hclustplot1(hierTOM,colorhvar, title1=paste("Height cutoff =", varheightcutoff)) 
}


####Heatmap for all modules
# for visualizing the network. Here we chose 2 scaling dimensions
windows()
cmd1=cmdscale(as.dist(dissTOM),2)
par(mfrow=c(1,1))
plot(cmd1, col=as.character(colorh1),  main="MDS plot", xlab="Scaling Dimension 1", ylab="Scaling Dimension 2")

windows()
TOMplot1(dissTOM , hierTOM, colorh1)


#Dynamic Tree Cut may identify modules whose expression profiles are very similar. It may be prudent to merge such modules since their genes are highly co-expressed
# Calculate eigengenes 


MEList = moduleEigengenes(datExprYeast[restConnectivity], colors = colorh1) 
MEs = MEList$eigengenes 
# Calculate dissimilarity of module eigengenes 
MEDiss = 1-cor(MEs); 
# Cluster module eigengenes 
METree = hclust(as.dist(MEDiss), method = "average"); 
# Plot the result 
windows() 
plot(METree, main = "Clustering of module eigengenes", xlab = "", sub = "")
#We choose a height cut of 0.25, corresponding to correlation of 0.75, to merge 
MEDissThres = 0.25 
# Call an automatic merging function 
merge = mergeCloseModules(datExprYeast[restConnectivity], colorh1, cutHeight = MEDissThres, verbose = 3) 
# The merged module colors 
mergedColors = merge$colors;
# Eigengenes of the new merged modules: 
mergedMEs = merge$newMEs;
#To see what the merging did to our module colors, we plot the gene dendrogram again, with the original and merged module colors underneath
windows()
#pdf(file = "Plots/geneDendro-3.pdf", wi = 9, he = 6) 
plotDendroAndColors(hierTOM, cbind(colorh1, mergedColors), c("Dynamic Tree Cut", "Merged dynamic"), dendroLabels = FALSE, hang = 0.03, addGuide = TRUE, guideHang = 0.05) 
# Rename to moduleColors 
moduleColors = mergedColors 
# Construct numerical labels corresponding to the colors 
colorOrder = c("grey", standardColors(50)); 
moduleLabels = match(moduleColors, colorOrder)-1; 
moduleColors = labels2colors(colorh1)
MEs = mergedMEs; 
geneTree = merge$dendrograms[[1]];

# The function verboseBarplot creates a bar plot
# that shows whether modules are enriched with essential genes.
# It also reports a Kruskal Wallis P-value.
# The gene significance can be a binary variable or a quantitative variable.
# also plots the 95% confidence interval of the mean
par(mfrow=c(1,1))
windows()
require(WGCNA)
verboseBarplot(GeneSignificance,colorh1,main="Module Significance ", col=levels(factor(colorh1)) ,xlab="Module", ylim=c(0,.5) )



###Gene reassignment, module trimming, and module "significance" criteria
reassignThreshold = 1e-6
minCoreKME = 0.5
minModuleSize = min(20, ncol(datExprYeast)/2 )
minCoreKMESize = minModuleSize/3
minKMEtoStay = 0.3
# Module merging options
mergeCutHeight = 0.15
impute = TRUE
trapErrors = FALSE
# Output options
numericLabels = FALSE
# Options controlling behaviour
nThreads = 0
verbose = 0
indent = 0



# Weighted network: Soft Thresholding Method
# First, we apply FDADJ() to a weighted network that uses power adjacency function with power1=7.
power1=7
time.start=Sys.time()
datExpr2 = datExprYeast[restConnectivity,]
for(i in 1:length(colorlevel1) ){
  adjtemp=cor(t(datExpr2[colorh1==colorlevel1[i],]), use="pairwise.complete.obs" )
  adjtemp= abs(adjtemp)^power1
  assign(paste("FDsoft", colorlevel1[i],sep=""), FDADJ(adjtemp))
  rm(adjtemp);
  collect_garbage()
}
time.end=Sys.time()
time.end-time.start # total time for running this part



# Construct the table 1.
module.soft=matrix(NA, ncol=length(colorlevel1), nrow= length(FDsoftturquoise$summary.names))
colnames(module.soft)=colorlevel1
rownames(module.soft)= FDsoftturquoise$summary.names
for(i in 1:length(colorlevel1)){
  temp=eval(as.name(paste("FDsoft",colorlevel1[i],sep="")))
  module.soft[,i]=temp$summary
}
signif(module.soft[-1,],3)
write.table(module.soft, "YeastNetwk11.xls", sep="\t", row.names=T, col.names=T)
# Heatmaps of TOM and Their Approximations by for All Modules
for(i in 1:length(colorlevel1) ){
  adjtemp=cor(t(datExpr2[colorh1==colorlevel1[i], ] ), use="pairwise.complete.obs" )
  adjtemp= abs(adjtemp)^power1
  dissGTOM2=TOMdist1(as.matrix(adjtemp))
  hierGTOM2 = hclust(as.dist(dissGTOM2),method="average");
  windows(width=4, height=4)
  TOMplot1(dissGTOM2 , hierGTOM2, rep(colorlevel1[i], module.soft[1,i]) )
  rm(adjtemp, dissGTOM2);collect_garbage()
  ### <plot>: TOM-GBM-brown-soft
  
  temp=eval(as.name(paste("FDsoft",colorlevel1[i],sep="")))
  temp=temp$kWithin
  dissGTOM2=matrix(NA, module.soft[1,i], module.soft[1,i])
  diag(dissGTOM2)=0
  for(j in 1: (module.soft[1,i]-1) )
    for(l in (j+1): module.soft[1,i] ){
      dissGTOM2[j,l]=max(temp[j], temp[l])
      dissGTOM2[l,j]= dissGTOM2[j,l]
    }
  dissGTOM2= dissGTOM2*(1+ module.soft[9,i]^2)/ module.soft[1,i]
  dissGTOM2=1- dissGTOM2
  #hierGTOM2 = hclust(as.dist(dissGTOM2),method="average");
  windows(width=4, height=4)
  TOMplot1(dissGTOM2 , hierGTOM2, rep(colorlevel1[i], module.soft[1,i]) )
  rm(dissGTOM2);
  collect_garbage()
}

####Module differential Analysis using MODA
library(MODA)
data(datExpr)
#datExpr1    = datExpr[restDegree,1:20]
#datExpr2    = datExpr[restDegree,1:24]
ResultFolder = 'ConditionSpecificModules' 
# where middle files are stored
CuttingCriterion =  'Density' 
# could be Density or Modularity
indicator1 =  'X' 
# indicator for data profile 1
indicator2 =  'Y' 
# indicator for data profile 2
specificTheta = 0.7
#threshold to define condition specific modules
conservedTheta = 0.7 
#threshold to define conserved modules
##modules detection for network 1
intModules1 <- WeightedModulePartitionDensity(datExprYeast,ResultFolder,indicator1,CuttingCriterion)
##  ..done.
##modules detection for network 2
intModules2 <- WeightedModulePartitionDensity(ADJ,ResultFolder,indicator2,CuttingCriterion)
JaccardMatrix <- comparemodulestwonets(ResultFolder,intModules1,intModules2,
                                       paste('/DenseModuleGene_',indicator1,sep=''),
                                       paste('/DenseModuleGene_',indicator2,sep=''))
CompareAllNets(ResultFolder,intModules1,indicator1,intModules2,
               indicator2,specificTheta,conservedTheta)


###Differential analysis
library(WGCNA) 
datExprB1 <- ADJ1
datExprB2 <- dat0
probesI = NodeNames 
Yeastdata <- na.omit(dat0)
dim(Yeastdata)
datExprYeast1=as.data.frame(t(Yeastdata[,-c(1:7)]))
names(datExprYeast1)
probesA = names(datExprYeast1)
#Get gene symbols for Yeast PPI dataset
library(org.Sc.sgd.db)
Symbol <- mget(probesI, org.Sc.sgdGENENAME)
genesI = Symbol
###ID = unlist(mget(probesA,org.Sc.sgdGENENAME))
Symbol1 <- mget(probesA, org.Sc.sgdGENENAME)
genesA = Symbol1
datExprB1g = (collapseRows(datExprB1,genesI,probesI))[[1]] 
datExprB2g = (collapseRows(datExprB2,genesA,probesA))[[1]] 
#limit your analysis to genes/probes that are expressed in both data sets
commonProbesA = intersect (rownames(ADJ1),rownames(dat0))
datExprA1p = ADJ1[commonProbesA,] 
datExprA2p = datExprYeast[commonProbesA,]
#commonGenesB = intersect (genesI,genesA) 
commonGenesB = intersect (rownames(datExprB1g),rownames(datExprB2g))
datExprB1g = datExprB1g[commonGenesB,] 
datExprB2g = datExprB2g[commonGenesB,] 
#Correlating general network properties
#Pick soft threshold
powers1=c(seq(1,10,by=1), seq(12,20, by=2))
RpowerTable=PickSoftThreshold(datExprYeast,powervector=powers1)[[2]]
collect_garbage()
abline(h=0.85,col="red")
plot(RpowerTable[,1], RpowerTable[,5],xlab="Soft Threshold (power)",ylab="Mean Connectivity", type="n")
text(RpowerTable[,1], RpowerTable[,5], labels=powers1, cex=cex1,col="red")

softPower = 10 # (Read WGCNA tutorial to learn how to pick your power) 
rankExprA1= rank(rowMeans(datExprA1p)) 
rankExprA2= rank(rowMeans(datExprA2p)) 
randomcommongenes= sample(commonProbesA,677) 
rankConnA1= rank(softConnectivity(t(datExprA1p[randomcommongenes,]),type="signed",power=softPower)) 
rankConnA2= rank(softConnectivity(t(datExprA2p[randomcommongenes,]),type="signed",power=softPower)) 
rankExprB1= rank(rowMeans(datExprB1g)) 
rankExprB2= rank(rowMeans(datExprB2g)) 
randomcommongenes= sample(commonGenesB,677) 

# Now we find the whole network connectivity measures for each:
rankConnB1= rank(softConnectivity(t(datExprB1g[randomcommongenes,]),type="signed",power=softPower)) 
rankConnB2= rank(softConnectivity(t(datExprB2g[randomcommongenes,]),type="signed",power=softPower)) 
pdf("generalNetworkProperties0999.pdf", height=10, width=9) 
par(mfrow=c(2,2)) 
verboseScatterplot(rankExprA1,rankExprA2, xlab="Ranked Expression (A1)",  
                   ylab="Ranked Expression (A2)") 
verboseScatterplot(rankConnA1,rankConnA2, xlab="Ranked Connectivity (A1)",  
                   ylab="Ranked Connectivity (A2)") 
verboseScatterplot(rankExprB1,rankExprB2, xlab="Ranked Expression (B1)",  
                   ylab="Ranked Expression (B2)") 
verboseScatterplot(rankConnB1,rankConnB2, xlab="Ranked Connectivity (B1)",  
                   ylab="Ranked Connectivity (B2)") 
dev.off() 

#choose the top 677 most expressed probes in data set A1
#and then keep only 1 probe per gene
keepGenesExpr = rank(-rowMeans(datExprA1p))<=677 
datExprA1g    = datExprA1p[keepGenesExpr,] 
datExprA2g    = datExprA2p[keepGenesExpr,] 
keepGenesDups = (collapseRows(datExprA1g,genesI,probesI))[[2]] 
datExprA1g    = datExprA1g[keepGenesDups[,2],] 
datExprA2g    = datExprA2g[keepGenesDups[,2],] 
rownames(datExprA1g)<-rownames(datExprA2g)<-keepGenesDups[,1] 

#calculate all of the necessary values to run WGCNA
library(WGCNA)
adjacencyA1 = adjacency(t(datExprA1g),power=softPower,type="signed"); 
diag(adjacencyA1)=0 
dissTOMA1   = 1-TOMsimilarity(adjacencyA1, TOMType="signed") 
geneTreeA1  = flashClust(as.dist(dissTOMA1), method="average") 
adjacencyA2 = adjacency(t(datExprA2g),power=softPower,type="signed"); 
diag(adjacencyA2)=0 
dissTOMA2   = 1-TOMsimilarity(adjacencyA2, TOMType="signed") 
library(flashClust)
geneTreeA2  = flashClust(as.dist(dissTOMA2), method="average") 
save.image("tutorial.RData")  #  (Section will take ~5-15 minutes to run) 

# display the networks visually
pdf("dendrogram1.pdf",height=6,width=16) 
par(mfrow=c(1,2)) 
plot(geneTreeA1,xlab="",sub="",main="Gene clustering on TOM-based dissimilarity (A1)", 
     labels=FALSE,hang=0.04); 
plot(geneTreeA2,xlab="",sub="",main="Gene clustering on TOM-based dissimilarity (A2)", 
     labels=FALSE,hang=0.04);  
dev.off() 


######Annotation
library(XML)
library(annotate)
library("org.Sc.sgd.db")
library(yeast2.db)
YPPIprobesI = NodeNames
gg <- getGO(YPPIprobesI, "org.Sc.sgd.db")
sum(is.na(gg))

datOutput=data.frame(ProbeID=YPPIprobesI, gg)
write.table(datOutput,"YPPINewResults.csv",row.names=F, sep=",")
write.table(datOutput,"YPPINewResults.txt",row.names=F, sep=",")

library(XML)
library(annotate)
library("org.Sc.sgd.db")
library(yeast2.db)
YCCprobesI = names(datExprYeast[restConnectivity])
gg <- getGO(YCCprobesI, "org.Sc.sgd.db")
sum(is.na(gg))
datOutput=data.frame(ProbeID=YPPIprobesI, gg)
write.table(datOutput,"YPPINewResults.csv",row.names=F, sep=",")
write.table(datOutput,"YPPINewResults.txt",row.names=F, sep=",")
names(datExprYeast[restConnectivity])[moduleColors=="turquoise"]# return probe IDs belonging to the black module
names(datExprYeast[restConnectivity])[moduleColors=="blue"]# return probe IDs belonging to the blue module
names(datExprYeast[restConnectivity])[moduleColors=="brown"]# return probe IDs belonging to the brown module
names(datExprYeast[restConnectivity])[moduleColors=="green"]# return probe IDs belonging to the grey module
names(datExprYeast[restConnectivity])[moduleColors=="yellow"]# return probe IDs belonging to the green module
names(datExprYeast[restConnectivity])[moduleColors=="black"]# return probe IDs belonging to the Red module
names(datExprYeast[restConnectivity])[moduleColors=="pink"]# return probe IDs belonging to the Turquoise module
names(datExprYeast[restConnectivity])[moduleColors=="red"]# return probe IDs belonging to the pink module
names(datExprYeast[restConnectivity])[moduleColors=="magenta"]# return


# Read in the probe annotation 
annot <- as.matrix(read.table("D:/JAEL Paper Aids/Thesis/WGCNA/Thesis/My project/data/GO.ann.yeast.28.03.13.3_300.txt"), fill = TRUE)
# Match probes in the data set to the probe IDs in the annotation file 
dim(annot)
rownames(annot)[1:10]
colnames(annot)[1:2000]
datExprA=as.data.frame(t(annot[,-c(1:8)]))
str(annot)#Checking the output
names(datExprA)
names(A)=t(datExprA)#transpose .txt data
y <- colnames(annot)
y <- unlist(lapply(y, function(x){
  substr(x, 3, 3) <- ":"; return(x)
}))
colnames(annot) <- y
x <- rownames(annot)

# Yeast GE DS: Match probes in the data set to those of the annotation file
probes = names(datExprYeast[restConnectivity])
head(probes)
table(datSummary$GeneSymbol)[moduleColors=="brown"]
names(datExprYeast[restConnectivity])[moduleColors=="turquoise"]# return probe IDs belonging to the black module
names(datExprYeast[restConnectivity])[moduleColors=="blue"]# return probe IDs belonging to the blue module
names(datExprYeast[restConnectivity])[moduleColors=="brown"]# return probe IDs belonging to the brown module
names(datExprYeast[restConnectivity])[moduleColors=="green"]# return probe IDs belonging to the grey module
names(datExprYeast[restConnectivity])[moduleColors=="yellow"]# return probe IDs belonging to the green module
names(datExprYeast[restConnectivity])[moduleColors=="black"]# return probe IDs belonging to the Red module
names(datExprYeast[restConnectivity])[moduleColors=="pink"]# return probe IDs belonging to the Turquoise module
names(datExprYeast[restConnectivity])[moduleColors=="red"]# return probe IDs belonging to the pink module
names(datExprYeast[restConnectivity])[moduleColors=="magenta"]# return probe IDs belonging to the yellow module

#names of pink YCC from data matching pink YPPI
Pnprobes = names(datExprYeast[restConnectivity])[moduleColors=="red"]
pkprobes = names(datExprADJ1[restDegreeADJ])[moduleColors=="black"]

probes2annot = match(probes, names(datExprA))
results <- cbind(probes, probes2annot)
head(results)
# The following is the number or probes without annotation:
sum(is.na(probes2annot)) 


###Compare blue module for Yppi n YGE
cBlprobes = match(Blprobes,names(datExprA))

#names(datExprYeast)[moduleColors=="black"]
Blprobes = names(datExprYeast[restConnectivity])[moduleColors=="blue"]
Blprobes2annot = match(Blprobes,names(datExprA))
sum(is.na(Blprobes2annot))
datOutput=data.frame(ProbeID=names(datExprYeast[restDegree])[moduleColors=="blue"], annot[Blprobes2annot,])
write.table(datOutput,"NowBlueYCCAnnotatioResults.csv",row.names=F, sep=",")

######Evaluation of randomGLM
# load required libraries
library(randomGLM)
library(mlbench)
options(stringsAsFactors=F)
# load data
data(dat0)
# check data
head(dat0)
# check outcome variable
y0 = as.factor(dat0[,51])
table(y0)

# define features
x0 = as.matrix(dat0[, -51])
mode(x0) = "numeric"
# m is total number of samples
m = nrow(x0)

# split data into 2/3 training and 1/3 test
set.seed(1)
indx = sample(1:m, ceiling(m/3))
x = x0[-indx,]
xtest = x0[indx,]
y = y0[-indx]
ytest = y0[indx]
# define accuracyMeasure
library(WGCNA)
accuracyM =function(predicted, y) {accuracyMeasures(table(predicted, y))[2,2]}
# RGLM prediction
# define function misclassification.rate, for accuracy calculation
if (exists("misclassification.rate") ) rm(misclassification.rate);
misclassification.rate=function(tab){
  num1=sum(diag(tab))
  denom1=sum(tab)
  signif(1-num1/denom1,3)
}

RGLM = randomGLM(x, y, xtest, 
                 classify=TRUE, 
                 keepModels=TRUE, 
                 nThreads=1)

# test set prediction
predictedTest = RGLM$predictedTest
tab1 = table(y, RGLM$predictedOOB)
# accuracy
accuracyM(predictedTest, ytest)
1-misclassification.rate(predictedTest)
